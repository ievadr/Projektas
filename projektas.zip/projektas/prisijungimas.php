<?php
session_start();

if ("POST" == $_SERVER["REQUEST_METHOD"]) {
	$_SESSION["host"] = strip_tags($_POST["host"]);
	$_SESSION["login"] = strip_tags($_POST["login"]);
	$_SESSION["pass"] = strip_tags($_POST["pass"]);
	header("Location: index.php");
	exit;
}

?>
<form action="" method="POST">
	Įveskite duomenų bazės hostą:<input type="text" name="host"><br>
	Įveskite duomenų bazės loginą:<input type="text" name="login"><br>
	Įveskite duomenų bazės slaptažodį:<input type="text" name="pass"><br>
	<input type="submit" name="pateikti" value="Pateikti">
</form>